
import BaseMiddleware from '../core/BaseMiddleware.js';
import {log,getEnv} from '../core/utils.js';
import { Redis } from './../global.js';

export default class AuthMiddleware extends BaseMiddleware
{
    constructor(){
        super();
    }

    async isAuth(req,res,next){
        try{
            let xToken = req.headers['x-token'] ?? '';
            if(xToken !== '')
            {
                xToken = xToken.trim();
                const key_access_token = getEnv('ACCESS_TOKEN_PREFIX') + xToken;
                const userToken = await Redis.getHash(key_access_token);
                if(userToken?.user_id)
                {
                    if(userToken?.status === "2")
                    {
                        req.userToken = userToken;
                        next();        
                    }
                    else
                    {
                        switch(userToken?.status)
                        {
                            case "0":
                                return res.json({"code":-3,"msg":"account is disabled!","is_auth":-3});
                            case "1":
                                return res.json({"code":-4,"msg":"account is blocked!","is_auth":-4});
                        }    
                    }
                }
                else
                {
                    return res.json({"code":-2,"msg":"token is invalid!","is_auth":-2});
                }
            }
            else
            {
                return res.json({"code":-1,"msg":"x-token not send","is_auth":-1});
            }
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


}

