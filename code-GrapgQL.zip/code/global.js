import Redis from "./core/redis.js";
import MongoDB from "./core/mongodb.js";
import { EventEmitter } from 'node:events';
import SocketIOServer from "./core/socketio.js";
const EmitterObject = new EventEmitter();
const RedisObject = new Redis();
const MongoObject = new MongoDB();
const IOObject = new SocketIOServer();

export {
    RedisObject as Redis,
    MongoObject as MongoDB,
    EmitterObject as Emitter,
    IOObject as io,
};