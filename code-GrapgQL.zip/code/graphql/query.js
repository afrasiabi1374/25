import getArticles from './query/getArticles.js';
import getArticle from './query/getArticle.js';
import getComments from './query/getComments.js';
import login from './query/login.js';
import getProfile from './query/getProfile.js';

export default {
    getArticles,
    getArticle,
    getComments,
    login,
    getProfile,
};