import {GraphQLError } from 'graphql';
import { log } from './../../core/utils.js';
import Helper from './../../core/helper.js';
import CommentModel from './../../models/comment.js';

export default {
    description: "get All Articles",
    resolve: async (_,{limit,page,sort_field,sort_type,article_id}) => {
      try{
        const helper = new Helper();
        limit = helper.getLimit(limit);
        page = helper.getPage(page);
        article_id = helper.toObjectId(article_id,true);
        if(article_id != '')
        {
          const sort = helper.getSortParams(['_id','updatedAt'],sort_field,sort_type);
          const model = new CommentModel();
          const result = await model.pagination(limit,page,sort.sort_field,sort.sort_type,article_id);
          return result;  
        }
        else
        {
          return new GraphQLError('article_id is not valid!');
        }
      }
      catch(e){
          return new GraphQLError(e.toString());
      }
  },
};


  
    