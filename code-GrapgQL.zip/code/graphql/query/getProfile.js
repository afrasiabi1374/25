import {GraphQLError } from 'graphql';
import { log } from './../../core/utils.js';
import Helper from './../../core/helper.js';
import UserModel from './../../models/user.js';
import Token from './../../core/token.js';


export default {
    description: "get Profile",
    resolve: async (_, {}, context) => {
      try{
        const helper = new Helper();
        if(!context?.user?.user_id)
        {
            return new GraphQLError("auth error!");
        }
        const model = new UserModel();
        return await model.getUser(context?.user?.user_id);
      }
      catch(e){
          return new GraphQLError(e.toString());
      }
  },
};


  
    