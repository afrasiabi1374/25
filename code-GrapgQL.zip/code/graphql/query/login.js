import {GraphQLError } from 'graphql';
import { log } from './../../core/utils.js';
import Helper from './../../core/helper.js';
import UserModel from './../../models/user.js';
import Token from './../../core/token.js';


export default {
    description: "login user",
    resolve: async (_,{email,password}) => {
      try{
        const helper = new Helper();
        email = helper.safeString(email);
        password = helper.safeString(password);

        const model = new UserModel();
        const user = await model.login(email,password);
        if(user && user?._id)
        {
            const t = await Token.generate(user._id,1);
            return {
              "access_token" : t?.access_token ,
              "refresh_token" : t?.refresh_token ,
              "message" : "Success!"
            };
        }
        else
        {
           return {
               "access_token" : "",
               "refresh_token" : "",
               "message" : "email or password is not correct!"
           };
        }

      }
      catch(e){
          return new GraphQLError(e.toString());
      }
  },
};


  
    