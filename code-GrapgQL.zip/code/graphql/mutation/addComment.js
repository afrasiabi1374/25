import {GraphQLError } from 'graphql';
import { log } from './../../core/utils.js';
import Helper from './../../core/helper.js';
import CommentModel from './../../models/comment.js';
import ArticleModel from './../../models/article.js';


export default {
    description: "add comment",
    resolve: async (_, {article_id,Message}, context) => {
      try{
        const helper = new Helper();
        if(!context?.user?.user_id)
        {
            return new GraphQLError("auth error!");
        }

        article_id = helper.toObjectId(article_id,true);
        if(article_id == '')
        {
          return new GraphQLError("article_id is not valid!");
        }

        const article = new ArticleModel();
        const row = await article.getRow(article_id);
        if(!row)
        {
          return new GraphQLError("article_id not found!");

        }

        Message = helper.safeString(Message);
        log(Message);
        if(Message == '')
        {
          return new GraphQLError("message is empty!");
        }

        const model = new CommentModel();
        await model.add(article_id,Message,context?.user?.user_id);
        return "OK!";
      }
      catch(e){
          return new GraphQLError(e.toString());
      }
  },
};


  
    