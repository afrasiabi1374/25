import addComment from './mutation/addComment.js';
export default {
    addComment,
};