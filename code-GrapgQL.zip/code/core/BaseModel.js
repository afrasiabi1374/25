import autoBind from 'auto-bind';
import {MongoDB} from '../global.js';
import { getEnv,log,toNumber,toObjectId } from './utils.js';
import {encode} from 'html-entities';
import {URLSearchParams} from 'node:url';
import UserSchema from './../schemas/user.js';
import ArticleSchema from './../schemas/article.js';
import CommentSchema from './../schemas/comment.js';

export default class BaseModel
{

    constructor()
    {
        this.#init();
        if(this.constructor === BaseModel)
        {
            throw new Error(`BaseModel is abstract class!`);
        }
        autoBind(this);
    }

    #init(){
        this.models = {
            "User" : MongoDB.db.model('user', UserSchema),
            "Article" : MongoDB.db.model('article', UserSchema),
            "Comment" : MongoDB.db.model('comment', CommentSchema),    
        };
    }


}