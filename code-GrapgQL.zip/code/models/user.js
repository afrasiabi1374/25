import {MongoDB} from '../global.js';
import {Models} from '../models.js';
import UserSchema from './../schemas/user.js';
import {log,toObjectId,getEnv} from './../core/utils.js';
import datetime from './../core/datetime.js';
import crypto from './../core/crypto.js';

export default class UserModel
{
    constructor(){
        this.model = Models.User;
    }

    async login(email,password){
        return await this.model.findOne({"email":email,"password":password});
    }

    async getUser(_id){
        return await this.model.findOne({"_id":_id});
    }
}



