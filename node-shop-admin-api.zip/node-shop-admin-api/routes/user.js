import { Router } from "express";
import {log} from '../core/utils.js';
import UserController from "../controllers/UserController.js";
import AuthMiddleware from '../middlewares/auth.js';
import RateLimitMiddleware from '../middlewares/ratelimit.js';
const controller = new UserController();
const route = Router();
try{
    route.post('/login',controller.login);
    //route.get('/logout',new AuthMiddleware().isAuth,controller.getLogout);
    //route.get('/profile',new AuthMiddleware().isAuth,controller.getProfile);
    //route.post('/profile',new AuthMiddleware().isAuth,controller.saveProfile);
}
catch(e){
    route.use(controller.errorHandling(e.toString()));
}

export default route;

