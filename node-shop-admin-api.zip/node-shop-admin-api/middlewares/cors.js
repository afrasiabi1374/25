
import BaseMiddleware from '../core/BaseMiddleware.js';
import {getEnv, log} from '../core/utils.js';

export default class CORSMiddleware extends BaseMiddleware
{
    constructor(){
        super();
    }

    async handle(req,res,next){
        try{
            const ALLOW_ORIGIN = getEnv('ALLOW_ORIGIN').split(',');
            const reqOrigin = req.headers.origin ?? '';
            if(reqOrigin !== '')
            {   
                const origin = ALLOW_ORIGIN.findIndex((value) => value === reqOrigin);
                if(origin >= 0)
                {
                    res.set({
                        'Access-Control-Allow-Origin' : ALLOW_ORIGIN[origin],
                        'Access-Control-Allow-Methods' : 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
                        'Access-Control-Allow-Headers' : 'Content-Type',
                    });        
                }
            }
            next();    
        }
        catch(e){
            next();
        }
    }

}
