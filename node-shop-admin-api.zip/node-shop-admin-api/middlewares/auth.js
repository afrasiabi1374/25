
import BaseMiddleware from '../core/BaseMiddleware.js';
import {log,getEnv} from '../core/utils.js';

export default class AuthMiddleware extends BaseMiddleware
{
    constructor(){
        super();
    }

    async isAuth(req,res,next){
        try{
            next();
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


}

