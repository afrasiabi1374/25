import BaseController from "../core/BaseController.js";
import translate from "../core/translate.js";
import {log, getEnv} from './../core/utils.js';

export default class HomeController extends BaseController
{
    constructor()
    {
        super();
        this.model = null;

    }
    
    async getIndex(req,res){
        try{
            const data = {
            }
            return res.json(data);
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }






}
