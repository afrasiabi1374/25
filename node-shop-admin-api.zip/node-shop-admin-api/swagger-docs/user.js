export default {
    "/user/login": {
      "post": {
        "tags": [
          "Users"
        ],
        "summary": "User Login",
        "description": "User Login",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "email",
            "in": "formData",
            "description": "email",
            "required": false,
            "type": "string"
          },
          {
            "name": "password",
            "in": "formData",
            "description": "password",
            "required": false,
            "type": "string"
          },
        ],
        "responses": {
          "200": {
            "description": "successful",
          },
        },
      },
    },
};
