import {Schema} from 'mongoose';

export default new Schema({
    updatedAt: {
        type: Date
    },
    createdAt: {
        type: Date
    },
    user: {
        type: Schema.Types.ObjectId,
        ref: "user"
    },
    article: {
        type: Schema.Types.ObjectId,
        ref: "article"
    },
    comment : {
        type : String,
        required : true,
    },
    approved : {
        type : Boolean,
        default: false
    }


});