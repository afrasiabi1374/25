import {Schema} from 'mongoose';
export default new Schema({
    updatedAt: {
        type: Date
    },
    createdAt: {
        type: Date
    },
    user: {
        type: Schema.Types.ObjectId,
        ref: "user"
    },
    title : {
        type : String,
        required : true,
    },
    body : {
        type : String
    }


});