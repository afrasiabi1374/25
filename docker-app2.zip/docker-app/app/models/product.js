import {MongoDB} from '../global.js';
import ProductSchema from './../schemas/product.js';
import {log,toObjectId,getEnv,random} from './../core/utils.js';
import datetime from './../core/datetime.js';
import crypto from './../core/crypto.js';

export default class ProductModel
{
    constructor(){
        this.model = MongoDB.db.model('product', ProductSchema);
    }

    async run(){
       /* const row = new this.model({
            "title":"TV",
            "price":1000,
            "color":["red","blue","pink"],
            "attr" : {
                "width" : 100,
                "height" : 200,
                "weight" : 500,
                "code"  : "tv1"
            }

        });
        await row.save();*/
        /*const row2 = new this.model({
            "title":"Lg",
            "price":50,
            "color":["red"],

        });
        await row2.save();*/
        //Push and pull
        //63c8efab46dcb09fb49affc8

        const data = {
            "user_id" : random(1,100) + "",
            "date_time" : datetime.toString(),
            "message" : `comment ${random(1,1000)} random text !@# `,
            "status" : random(0,1)
        };

        const result = await this.model.updateOne({"_id":"63c8efab46dcb09fb49affca"},{
            "$push" : {
                "comments" : data
            }
        });



    }


    

}



