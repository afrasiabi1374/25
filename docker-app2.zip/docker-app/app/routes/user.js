import { Router } from "express";
import {log} from '../core/utils.js';
import UserController from "../controllers/UserController.js";
import AuthMiddleware from '../middlewares/auth.js';
import RateLimitMiddleware from '../middlewares/ratelimit.js';
const controller = new UserController();
const route = Router();
try{
    route.post('/login',controller.login);
    route.post('/check-token',new AuthMiddleware().isAuth,controller.checkToken);
    route.get('/profile',new AuthMiddleware().isAuth,controller.profile);
    route.post('/refresh-token',controller.refreshToken);//rate limit
    route.post('/logout',new AuthMiddleware().isAuth,controller.logout);
    route.put('/upload-avatar',new AuthMiddleware().isAuth,controller.uploadAvatar);
    route.delete('/remove-avatar',new AuthMiddleware().isAuth,controller.removeAvatar);
    route.put('/update-profile',new AuthMiddleware().isAuth,controller.updateProfile);
}
catch(e){
    route.use(controller.errorHandling(e.toString()));
}

export default route;

