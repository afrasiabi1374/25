import Users from './../../userDBTest.js';
import {GraphQLError } from 'graphql';


export default {
    description: "delete User by id",
    resolve: async (_,{id}) => {
      try{
        const userIndex = Users.findIndex((row) => row.id == id);
        if(userIndex > -1)
        {
           Users.splice(userIndex,1);
           return "Delete Success!";
        }
        else
        {
            return new GraphQLError(`user not found!`);
        }
    }
    catch(e){
        return new GraphQLError(e.toString());
    }
  },
};


  
    