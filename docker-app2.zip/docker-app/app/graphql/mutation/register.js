import Users from './../../userDBTest.js';
import {GraphQLError } from 'graphql';

export default {
    description: "register new user",
    resolve: async (_,{fn,ln}) => {
      try {
        Users.push({
          "id" : Users.length + 1,
          "fn" : fn,
          "ln" : ln,
        });
        return "Register Success!";
      } catch (e) {
        return new GraphQLError(e.toString());
      }
    },
};


  
    