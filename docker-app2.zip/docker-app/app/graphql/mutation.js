import register from './mutation/register.js';
import Delete from './mutation/delete.js';
export default {
    register,
    Delete,
};