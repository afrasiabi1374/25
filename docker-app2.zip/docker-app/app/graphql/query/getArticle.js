import {GraphQLError } from 'graphql';
import { log } from '../../core/utils.js';
import Helper from '../../core/helper.js';
import ArticleModel from '../../models/article.js';
export default {
    description: "get single article by id",
    resolve: async (_,{_id}) => {
      try{
        const helper = new Helper()
        _id = helper.toObjectId(_id, true)
        if (_id != "") {
          const model = new ArticleModel()
          const row =await model.getRow(_id)
          if (row) {
            return row
          }else{
            return new GraphQLError('row not found!');
          }
        }
        else{
          return new GraphQLError('id not valid!');
        }
      }
      catch(e){
        return new GraphQLError(e.toString());
      }
  },
};


  
    