import {GraphQLError } from 'graphql';
import { log } from '../../core/utils.js';
import Helper from '../../core/helper.js';
import ArticleModel from './../../models/article.js';


export default {
    description: "get all article",
    resolve: async (_,{limit ,page, sort_field, sort_type, title}) => {
      try{
        const helper = new Helper()
        limit = helper.getLimit(limit)
        page = helper.getPage(page)
        title = helper.safeString(title)
        const sort = helper.getSortParams(['_id', 'title', 'updatedAt'], sort_field, sort_type)
        const model = new ArticleModel()
        const result = await model.pagination(limit,page, sort.sort_field, sort.sort_type, title)
        return result
      }
      catch(e){
        return new GraphQLError(e.toString());
      }
  },
};


  
    