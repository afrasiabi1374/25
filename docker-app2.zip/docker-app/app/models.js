import { MongoDB } from "./global.js";
import ArticleSchema from './schemas/article.js'
import UserSchema from './schemas/user.js'
import CommentSchema from './schemas/comment.js'
let Models = {}

function bindModels() {
    Models = {
        "User": MongoDB.db.model('user', UserSchema),
        "Article": MongoDB.db.model('article', ArticleSchema),
        "Comment": MongoDB.db.model('comment', CommentSchema)
    }
}

export  {Models, bindModels}