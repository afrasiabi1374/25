import BaseController from "../core/BaseController.js";
import {validationResult,body} from 'express-validator';
import translate from "../core/translate.js";
import crypto from './../core/crypto.js';
import {isFile,unlink,fileExists} from './../core/fs.js';
import {allowImageFileUpload,fileNameGenerator,toByte} from './../core/uploader.js';
import {random,stringify,log, getEnv,getPath} from './../core/utils.js';
import datetime from './../core/datetime.js';
import CategoryModel from './../models/category.js';

export default class CategoryController extends BaseController
{
    #url =  getEnv('APP_URL') + 'category/';

    constructor()
    {
        super();
        this.model = new CategoryModel();
    }
    
    async add(req,res){
        try{
            const mainCategory = await this.model.getMainCategoryList();
            const data = {
                "title" : translate.t('category.page_title'),
                "form_data" : req?.session?.category_add_data,
                "mainCategory" : mainCategory,
            }
            return res.render('category/add',data);
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async #validation(req){
        await body('parent_id').not().isEmpty().withMessage("err1").run(req);
        await body('title').not().isEmpty().withMessage("err2").run(req);
        await body('title_seo').not().isEmpty().withMessage("err3").run(req);
        await body('description_seo').not().isEmpty().withMessage("err4").run(req);
        await body('slug').not().isEmpty().withMessage("err5").custom(() => {
            const slug = this.input(req.body.slug);
            const check = /^[a-z0-9-]+$/.test( slug );
            if(check)
                return true;
            else
                throw new Error("err6");
        }).run(req);
        return validationResult(req);   
    }

    async postAdd(req,res){
        try{
            const parent_id = this.safeString(this.input(req.body.parent_id));
            const title = this.safeString(this.input(req.body.title));
            const title_seo = this.safeString(this.input(req.body.title_seo));
            const description_seo = this.safeString(this.input(req.body.description_seo));
            const slug = this.safeString(this.input(req.body.slug));
            const status = this.safeString(this.input(req.body.status));
            const formData = {parent_id,title,title_seo,description_seo,slug,status};
            req.session.category_add_data = formData;
            if(!this.checkCsrfToken(req))
            {
                return res.redirect(`${this.#url}add/?msg=csrf_token_invalid`);
            }
            const result = await this.#validation(req);
            if(!result.isEmpty())
            {
                return res.redirect(`${this.#url}add/?msg=${result?.errors[0]?.msg}`);
            }  
            else
            {
                if(parent_id !== "0")
                {
                    if(!this.toObjectId(parent_id))
                    {
                        return res.redirect(`${this.#url}add/?msg=parent_id_invalid`);
                    }
                }
                const resultAdd = await this.model.add(parent_id,title,title_seo,description_seo,slug,status);
                if(typeof resultAdd === 'number')
                    return res.redirect(`${this.#url}add/?msg=${resultAdd}`);
                else if(resultAdd?._id)
                {
                    delete req.session.category_add_data;
                    return res.redirect(`${this.#url}add/?msg=ok`);
                }
                else
                    return res.redirect(`${this.#url}add/?msg=error`);
            }
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }

    #getParams(req){
        try{
            let parent_id = this.safeString(this.input(req.query.parent_id));
            parent_id = (parent_id === "0") ? 0 : this.toObjectId(parent_id,true); 
            const title = this.safeString(this.input(req.query.title));
            const params = {
                parent_id,title
            };
            const paramsQuery = this.toQuery(params);
            return {
                "params" : params,
                "params_query" : paramsQuery,
            }    
        }
        catch(e){
            return {
                "params" : {},
                "params_query" : '',
            }    
        }
    }

    async index(req,res){
        try{
            const sortFields = ['_id','parent_id','title','last_edit_date_time','status'];
            const {page,sort_field,sort_type} = this.handlePagination(req,sortFields);
            const status_id = this.toObjectId(this.input(req.query.status_id),true);
            const status_value = this.toNumber(this.input(req.query.status_value),true);
            const {params,params_query} = this.#getParams(req);
            const url = this.#url + '?' + params_query;
            const route_url = this.#url;

            if(status_id !== '')
            {
                await this.model.changeStatus(status_id,status_value);
                return res.redirect(url + `&page=${page}&msg=status_changed`);
            }

            const mainCategory = await this.model.getMainCategoryList();
            const pagination = await this.model.pagination(page,sort_field,sort_type,params?.parent_id,params?.title);
            const data = {
                "title" : translate.t("menu_category_list"),
                "pagination" : pagination,
                "url" : url,
                "route_url" : route_url,
                "sortFields" : sortFields,
                "mainCategory" : mainCategory,
                "params" : params,
                "params_query" : params_query,
                "page" : page,
            }
            return res.render('category/index',data);
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


    async edit(req,res){
        try{
            const page = this.getPage(req);
            const {params,params_query} = this.#getParams(req);
            const back_url = this.#url + '?' + params_query + `&page=${page}`;
            const editId = this.toObjectId(this.input(req.params.edit_id),true);
            if(editId === '')
            {
                return res.redirect(back_url);
            }
            const rowData = await this.model.getRow(editId);
            if(!rowData)
            {
                return rowData.redirect(back_url);
            }
            const row = rowData.toJSON();
            row.parent_id = (row.parent_id) ? row.parent_id += '' : 0;
            const mainCategory = await this.model.getMainCategoryList();
            const data = {
                "title" : translate.t("category.page_title_edit"),
                "back_url" : back_url,
                "mainCategory" : mainCategory,
                "row" : row,
            }
            return res.render('category/edit',data);
        }
        catch(e){
            return super.toError(e,req,res);
        }
    }


   





}
