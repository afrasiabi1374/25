var category = {
};

$(window).on('load', function() {
});