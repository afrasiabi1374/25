JS_LANG = {
    "logout_title" : "خروج",
    "logout_text" : "آیا میخواهید خارج شوید ؟",
    "logout_yes" : "بله",
    "logout_no" : "خیر",
    "logout_no" : "خیر",
    "validation_slug_required" : "لطفا slug را وارد نمایید.",
    "validation_slug_invalid" : "slug معتبر نمی باشد . <span dir=\"ltr\"> a to z , 0 to 9 , - </span> ",
};