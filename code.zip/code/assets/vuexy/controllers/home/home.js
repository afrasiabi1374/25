$(window).on('load', function() {
    //alert(t('home.login'));
});