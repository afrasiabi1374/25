$(window).on('load', function() {

    $('#parent_id').select2({"width":"100%"});

    $('#form-edit').validate({
        rules:{
            parent_id : "required",
            title : "required",
            title_seo : "required",
            description_seo : "required",
            slug : {
                required : true,
                slug : true,
            },
        },
        messages:{
            parent_id : t('category.validation_parent_id_required'),
            title : t('category.validation_title_required'),
            title_seo : t('category.validation_title_seo_required'),
            description_seo : t('category.validation_description_seo_required'),
            slug :{
                required :  t('validation_slug_required'),
                "slug" : t('validation_slug_invalid'),
            },
        }
    });


});
