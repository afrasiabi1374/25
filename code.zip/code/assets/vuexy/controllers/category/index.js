$(window).on('load', function() {

    $('#parent_id').select2({"width":"100%"});


});
