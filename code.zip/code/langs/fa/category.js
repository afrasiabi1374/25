export default {
    "page_title" : "دسته بندی جدید",
    "page_title_edit" : "ویرایش دسته بندی",
    "add" : "دسته بندی جدید",
    "parent_id" : "والد دسته",
    "main" : "دسته اصلی",
    "title" : "عنوان دسته",
    "validation_parent_id_required" : "لطفا والد دسته را انتخاب نمایید.",
    "validation_title_required" : "لطفا عنوان دسته را وارد نمایید.",
    "validation_title_seo_required" :  "لطفا عنوان صفحه SEO را وارد نمایید.",
    "validation_description_seo_required" : "لطفا توضیحات SEO را وارد نمایید.",
    "parent_id_invalid" : "والد دسته معتبر نمی باشد.",
    "title_is_alreday" : "عنوان دسته تکراری می باشد.",

};