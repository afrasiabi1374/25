import {MongoDB} from '../global.js';
import CategorySchema from './../schemas/category.js';
import {log,toObjectId,getEnv} from './../core/utils.js';
import datetime from './../core/datetime.js';
import crypto from './../core/crypto.js';

export default class CategoryModel
{
    constructor(){
        this.model = MongoDB.db.model('category', CategorySchema);
    }

    async add(parent_id,title,title_seo,description_seo,slug,status){
        parent_id = (parent_id === "0") ? null : parent_id;
        const last_edit_date_time = datetime.toString();
        const isDupTitle = await this.#checkTitle(parent_id,title);
        if(isDupTitle > 0)
        {
            return -1;//title is already
        }
        const isDupSlug = await this.#checkSlug(slug);
        if(isDupSlug > 0)
        {
            return -2;//slug is already
        }
        const row = new this.model({
            parent_id,title,title_seo,description_seo,slug,status,last_edit_date_time
        });
        return await row.save();
    }


    async #checkTitle(parent_id,title){
        return this.model.findOne({"parent_id":parent_id,"title":title}).countDocuments();
    }


    async #checkSlug(slug){
        return this.model.findOne({"slug":slug}).countDocuments();
    }

    async getMainCategoryList(){
        return await this.model.find({"parent_id":null}).sort([['title',1]]);
    }


    async pagination(page,sortField,sortType,parent_id,title){
        const where = {};

        if(parent_id !== '')
        {
            parent_id = (parent_id === 0) ? null : parent_id;
            where['parent_id'] = parent_id;
        }

        if(title !== '')
        {
            where['title'] = {$regex: '.*' + title + '.*', "$options": "i"};
        }

        const ROWS_PRE_PAGE = getEnv('ROWS_PRE_PAGE','number');
        const skip = ROWS_PRE_PAGE * page - ROWS_PRE_PAGE;
        const totalRows = await this.model.findOne(where).countDocuments();
        const totalPage = Math.ceil(totalRows / ROWS_PRE_PAGE);
        const rows =  await this.model.find(where).sort([[sortField,sortType]]).populate('parent_id',{title:1})
        .skip(skip)
        .limit(ROWS_PRE_PAGE);
        return {
            rows,totalRows,totalPage
        };

    }


    async changeStatus(status_id,status_value){
        const last_edit_date_time = datetime.toString();
        const data = {
            "status" : status_value,
            "last_edit_date_time" : last_edit_date_time,
        };
        
        await this.model.updateOne({"_id":status_id},{
            "$set" : data 
        });

        return 1;
    }

    async getRow(id){
        return this.model.findOne({"_id":id});
    }

}



