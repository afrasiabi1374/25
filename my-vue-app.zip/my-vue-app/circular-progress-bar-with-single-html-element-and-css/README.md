# Circular progress bar with single HTML element and CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/poWgdVV](https://codepen.io/alvaromontoro/pen/poWgdVV).

Watch how it was coded with a step-by-step explanation of the process: https://www.youtube.com/watch?v=aXmNG2wie7I