<template>
    <h1>life cycle</h1>
    <button @click="counter++">plus</button>
</template>
<script lang="ts" setup>
import { onActivated } from 'vue';

onActivated(()=>{
    console.log('Actived');
    
})


</script>