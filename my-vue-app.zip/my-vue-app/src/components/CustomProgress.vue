<template>

</template>
<script setup >
import { getCurrentInstance, onUnmounted, ref } from 'vue';
    const emit = defineEmits(['scrolledArea'])
    const props = defineProps({
      progress:{
        type: Number
      },
      element:{
        type: Element
      }
    })
    
    window.onscroll = () => {
      const el = document.getElementById('scrollTrackPercent').getBoundingClientRect()
      const height = el.height
      const top = el.top
      // const calcTopOfToBottomOfEl = ref((top/height) * 100) 
      // console.log(el);
      let emitValue = 0
      if (el.bottom < 0) {
        emitValue = 100
      }else if(top < 0 && el.bottom > 0 ){
        emitValue = -(Math.floor((top)/(height)*100))
      }else{
        emitValue = 0
      }
      emit('scrolledArea', emitValue)
      if (el.bottom >= 0 && el.top <= 0) {
      }
    }
    let percentage = ref(0)
    const onScroll = function (event) {
        const post = event.target
        const st = post.scrollTop
        const sh = post.scrollHeight
        const ch = post.clientHeight

        percentage.value = Math.floor(st/(sh - ch)*100)
    
        console.log( percentage.value)

    }
    onUnmounted(()=>{
      window.removeEventListener("scroll")
    })

</script>
<style scoped>
  
</style>
