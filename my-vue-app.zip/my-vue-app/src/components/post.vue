<template>
    <div class="parent"> 
        <div  class="prc">{{percentage}}% </div>
    </div>
    <custom-progress @scrolledArea="(n)=> percentage = n" :progress="percentage" />
    <div style="position: fixed;">{{ percentage }}</div>
    <div >Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem modi, repellendus assumenda neque hic esse accusantium sint ducimus iure nam expedita at dolorem fugit maxime commodi nihil beatae quae! Molestias quaerat doloremque totam quia nisi perspiciatis soluta illum velit officiis nostrum consequatur inventore, iure sed est neque ab dolores eveniet voluptatum architecto fugiat? Quasi id nemo dolorum explicabo sequi magni deserunt nostrum nam excepturi laudantium, voluptate natus debitis dicta, expedita cupiditate veniam voluptates recusandae assumenda adipisci accusantium porro perspiciatis nihil. Quaerat repellat, dolores perspiciatis harum aut facere molestiae voluptates nemo quis praesentium similique quas reprehenderit voluptatum, possimus iusto quibusdam? Incidunt rem rerum blanditiis impedit amet in. Cumque, architecto beatae. Sed odit minima alias mollitia sit id repellat aut eligendi veritatis maxime explicabo ducimus, recusandae perferendis incidunt reprehenderit tempore iure dolor, eos provident magni est commodi libero. Ab aliquam dicta blanditiis nulla enim ea odio sapiente mollitia excepturi expedita eum hic cum, ducimus vero commodi asperiores, minima, consequatur exercitationem pariatur dolor quibusdam? Porro doloremque dicta, reprehenderit laborum modi culpa fuga nisi ut vel enim nostrum temporibus molestiae odio perferendis totam praesentium, repellat sapiente non rem eveniet, quod consequatur ullam necessitatibus illum! Voluptates suscipit aspernatur corrupti quis aperiam ratione dignissimos! Facere officia similique, tempora consequatur perferendis non rerum voluptas minus voluptate id aspernatur repellat. Cum magnam mollitia repudiandae saepe, explicabo facilis quod dicta dolorem nisi repellendus. Unde molestias deserunt iusto ex id, voluptatibus harum nihil reiciendis eos sit nulla, ut sunt laudantium consectetur maxime quae veniam illo sequi culpa qui amet dolores iste magni! Magni deserunt, necessitatibus dicta sit reiciendis magnam. Amet veniam quibusdam consectetur tenetur perspiciatis ipsum vitae ab beatae qui vel saepe error, autem aliquam, possimus nulla ut rem ex repellendus mollitia voluptates ipsa aspernatur inventore voluptatem omnis! Eligendi dignissimos quisquam modi? Consectetur hic, animi delectus voluptas assumenda modi ut vitae nam quo numquam voluptate repudiandae, maxime, odio laborum. Distinctio quibusdam quisquam sint tempore similique ipsa, consectetur beatae veritatis autem soluta suscipit earum placeat molestiae dolorem nihil tempora eaque, consequuntur perspiciatis ipsum quia eum? Ratione sed necessitatibus aliquam fugit rerum iure nostrum repudiandae dolor alias doloribus porro eveniet autem quidem accusamus voluptate ea tempore ab aperiam quod minima, architecto possimus error aut? Sapiente in maxime reiciendis quis nam impedit quaerat, tempora et perferendis perspiciatis eveniet, possimus illum, quas aspernatur animi culpa quisquam. Dicta nemo vitae repellat mollitia, et suscipit illum delectus ipsum quibusdam voluptatem corrupti, vero unde similique facere eos, impedit fugit quos! Est ipsum dolores eum quia earum illo quasi perspiciatis quo, voluptates a odio. Culpa unde facilis pariatur, voluptas atque nihil a? Explicabo, quibusdam aspernatur qui provident nulla cum amet blanditiis natus voluptatem nihil, voluptates, alias odio nisi ea quas fugit a assumenda? Tempore dolorem ipsa dignissimos nam ex, incidunt quod, aperiam non placeat libero voluptas ullam et nostrum voluptatum eveniet rerum quisquam nobis minus eligendi cumque ipsam aspernatur, eius at saepe! Similique, quas quam voluptatibus temporibus corrupti et consectetur ullam? Doloremque omnis dolores veritatis eius iure esse aperiam atque nisi animi! Praesentium hic maxime ab porro perspiciatis, facere adipisci exercitationem illum neque incidunt cupiditate iste quod doloremque earum officia nobis optio eligendi dignissimos eaque dolore cum esse nemo aliquid! Laboriosam quae veniam nemo vero qui aspernatur, dolores ab, commodi sapiente rerum deserunt minus libero adipisci cumque doloremque perferendis obcaecati repudiandae dolor. Explicabo ducimus voluptas nam quis ea suscipit officia, asperiores dignissimos iusto doloremque laudantium. Voluptatum dolorum dolores vitae, placeat sit sapiente molestias, asperiores expedita voluptate natus voluptatem nesciunt veniam obcaecati repellendus explicabo quaerat culpa totam ab. Suscipit omnis rerum excepturi, id perspiciatis perferendis velit officiis laboriosam officia, deserunt voluptate numquam vel est illum incidunt sunt beatae blanditiis doloremque cumque quasi reprehenderit ex nostrum? Quod consequatur nemo totam dolore laborum? Eum quae nostrum commodi recusandae asperiores quibusdam magni facilis voluptatibus, fuga aliquam. Qui mollitia repudiandae reiciendis labore quae deserunt placeat dolor architecto repellat ipsam id atque esse explicabo doloribus, eum itaque! Amet ex molestiae esse officia eos nihil nam sapiente aliquam vel in libero deserunt quam, praesentium beatae rerum delectus natus a explicabo quos necessitatibus ducimus ipsa aspernatur! Odit culpa natus eligendi nostrum magnam excepturi nihil rem in neque voluptatum nesciunt molestias beatae quae alias, cum consequatur repellat enim sed eveniet sapiente quasi dolorem distinctio! Perspiciatis odio at, eaque excepturi totam incidunt rem. Reiciendis animi delectus, porro dicta at est possimus, placeat nostrum excepturi neque eos consequuntur incidunt magni, mollitia ipsum impedit distinctio laborum! Nihil eligendi totam laudantium dolore inventore reprehenderit perferendis aut neque? Quae omnis dolores aliquam laudantium eligendi expedita perspiciatis officia asperiores aspernatur harum. Maxime repellendus, fuga labore nesciunt, tenetur eum dolore laboriosam perspiciatis consectetur voluptas deleniti distinctio molestiae commodi quod officia reprehenderit incidunt modi esse ipsam ducimus ut suscipit unde eius ab. Non culpa quisquam quis debitis! Id veniam aliquid aperiam rerum incidunt, expedita similique quisquam harum ut maiores aspernatur qui quibusdam excepturi sed culpa ea commodi iusto eaque itaque corrupti quasi, exercitationem minima, obcaecati tenetur. Veniam quas numquam dignissimos sequi sapiente quisquam reiciendis tempora ipsam vitae similique. Quasi expedita similique optio, necessitatibus obcaecati suscipit, iste impedit iure voluptatum aliquid, incidunt repellat ad libero aliquam id quae eaque cupiditate neque. Incidunt dolores iure id? Repudiandae neque adipisci nam provident optio repellendus iure recusandae, vero exercitationem enim totam. Distinctio eligendi incidunt sequi a veniam saepe illum eos, corrupti eaque maxime blanditiis mollitia animi? Tenetur, neque? Nisi quas quisquam, obcaecati vero ut laboriosam ab eum aliquid accusamus quod praesentium et! Architecto quo atque beatae explicabo reprehenderit placeat deserunt dolorum repellendus modi quod dolores voluptas voluptatum vero sunt laudantium consequatur voluptate odit nemo, doloribus quia facere. Ad tempora quod fuga, sapiente asperiores delectus blanditiis quas nesciunt enim, incidunt sunt numquam facilis beatae provident repellendus voluptatum maiores quis magnam aut voluptatibus at quos quibusdam magni officia. Impedit delectus consequatur, at libero omnis obcaecati nisi neque ipsum quia. Voluptas itaque aspernatur quos illum sed. Officiis maxime totam itaque officia veritatis molestiae aspernatur consequatur dolores recusandae, nobis illum odio quae ea blanditiis odit corrupti vero ullam similique eveniet ipsam culpa reprehenderit. Ad modi placeat consequuntur ex doloremque harum facilis eum fugit.</div>
    <hr>
    <div id="scrollTrackPercent">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem modi, repellendus assumenda neque hic esse accusantium sint ducimus iure nam expedita at dolorem fugit maxime commodi nihil beatae quae! Molestias quaerat doloremque totam quia nisi perspiciatis soluta illum velit officiis nostrum consequatur inventore, iure sed est neque ab dolores eveniet voluptatum architecto fugiat? Quasi id nemo dolorum explicabo sequi magni deserunt nostrum nam excepturi laudantium, voluptate natus debitis dicta, expedita cupiditate veniam voluptates recusandae assumenda adipisci accusantium porro perspiciatis nihil. Quaerat repellat, dolores perspiciatis harum aut facere molestiae voluptates nemo quis praesentium similique quas reprehenderit voluptatum, possimus iusto quibusdam? Incidunt rem rerum blanditiis impedit amet in. Cumque, architecto beatae. Sed odit minima alias mollitia sit id repellat aut eligendi veritatis maxime explicabo ducimus, recusandae perferendis incidunt reprehenderit tempore iure dolor, eos provident magni est commodi libero. Ab aliquam dicta blanditiis nulla enim ea odio sapiente mollitia excepturi expedita eum hic cum, ducimus vero commodi asperiores, minima, consequatur exercitationem pariatur dolor quibusdam? Porro doloremque dicta, reprehenderit laborum modi culpa fuga nisi ut vel enim nostrum temporibus molestiae odio perferendis totam praesentium, repellat sapiente non rem eveniet, quod consequatur ullam necessitatibus illum! Voluptates suscipit aspernatur corrupti quis aperiam ratione dignissimos! Facere officia similique, tempora consequatur perferendis non rerum voluptas minus voluptate id aspernatur repellat. Cum magnam mollitia repudiandae saepe, explicabo facilis quod dicta dolorem nisi repellendus. Unde molestias deserunt iusto ex id, voluptatibus harum nihil reiciendis eos sit nulla, ut sunt laudantium consectetur maxime quae veniam illo sequi culpa qui amet dolores iste magni! Magni deserunt, necessitatibus dicta sit reiciendis magnam. Amet veniam quibusdam consectetur tenetur perspiciatis ipsum vitae ab beatae qui vel saepe error, autem aliquam, possimus nulla ut rem ex repellendus mollitia voluptates ipsa aspernatur inventore voluptatem omnis! Eligendi dignissimos quisquam modi? Consectetur hic, animi delectus voluptas assumenda modi ut vitae nam quo numquam voluptate repudiandae, maxime, odio laborum. Distinctio quibusdam quisquam sint tempore similique ipsa, consectetur beatae veritatis autem soluta suscipit earum placeat molestiae dolorem nihil tempora eaque, consequuntur perspiciatis ipsum quia eum? Ratione sed necessitatibus aliquam fugit rerum iure nostrum repudiandae dolor alias doloribus porro eveniet autem quidem accusamus voluptate ea tempore ab aperiam quod minima, architecto possimus error aut? Sapiente in maxime reiciendis quis nam impedit quaerat, tempora et perferendis perspiciatis eveniet, possimus illum, quas aspernatur animi culpa quisquam. Dicta nemo vitae repellat mollitia, et suscipit illum delectus ipsum quibusdam voluptatem corrupti, vero unde similique facere eos, impedit fugit quos! Est ipsum dolores eum quia earum illo quasi perspiciatis quo, voluptates a odio. Culpa unde facilis pariatur, voluptas atque nihil a? Explicabo, quibusdam aspernatur qui provident nulla cum amet blanditiis natus voluptatem nihil, voluptates, alias odio nisi ea quas fugit a assumenda? Tempore dolorem ipsa dignissimos nam ex, incidunt quod, aperiam non placeat libero voluptas ullam et nostrum voluptatum eveniet rerum quisquam nobis minus eligendi cumque ipsam aspernatur, eius at saepe! Similique, quas quam voluptatibus temporibus corrupti et consectetur ullam? Doloremque omnis dolores veritatis eius iure esse aperiam atque nisi animi! Praesentium hic maxime ab porro perspiciatis, facere adipisci exercitationem illum neque incidunt cupiditate iste quod doloremque earum officia nobis optio eligendi dignissimos eaque dolore cum esse nemo aliquid! Laboriosam quae veniam nemo vero qui aspernatur, dolores ab, commodi sapiente rerum deserunt minus libero adipisci cumque doloremque perferendis obcaecati repudiandae dolor. Explicabo ducimus voluptas nam quis ea suscipit officia, asperiores dignissimos iusto doloremque laudantium. Voluptatum dolorum dolores vitae, placeat sit sapiente molestias, asperiores expedita voluptate natus voluptatem nesciunt veniam obcaecati repellendus explicabo quaerat culpa totam ab. Suscipit omnis rerum excepturi, id perspiciatis perferendis velit officiis laboriosam officia, deserunt voluptate numquam vel est illum incidunt sunt beatae blanditiis doloremque cumque quasi reprehenderit ex nostrum? Quod consequatur nemo totam dolore laborum? Eum quae nostrum commodi recusandae asperiores quibusdam magni facilis voluptatibus, fuga aliquam. Qui mollitia repudiandae reiciendis labore quae deserunt placeat dolor architecto repellat ipsam id atque esse explicabo doloribus, eum itaque! Amet ex molestiae esse officia eos nihil nam sapiente aliquam vel in libero deserunt quam, praesentium beatae rerum delectus natus a explicabo quos necessitatibus ducimus ipsa aspernatur! Odit culpa natus eligendi nostrum magnam excepturi nihil rem in neque voluptatum nesciunt molestias beatae quae alias, cum consequatur repellat enim sed eveniet sapiente quasi dolorem distinctio! Perspiciatis odio at, eaque excepturi totam incidunt rem. Reiciendis animi delectus, porro dicta at est possimus, placeat nostrum excepturi neque eos consequuntur incidunt magni, mollitia ipsum impedit distinctio laborum! Nihil eligendi totam laudantium dolore inventore reprehenderit perferendis aut neque? Quae omnis dolores aliquam laudantium eligendi expedita perspiciatis officia asperiores aspernatur harum. Maxime repellendus, fuga labore nesciunt, tenetur eum dolore laboriosam perspiciatis consectetur voluptas deleniti distinctio molestiae commodi quod officia reprehenderit incidunt modi esse ipsam ducimus ut suscipit unde eius ab. Non culpa quisquam quis debitis! Id veniam aliquid aperiam rerum incidunt, expedita similique quisquam harum ut maiores aspernatur qui quibusdam excepturi sed culpa ea commodi iusto eaque itaque corrupti quasi, exercitationem minima, obcaecati tenetur. Veniam quas numquam dignissimos sequi sapiente quisquam reiciendis tempora ipsam vitae similique. Quasi expedita similique optio, necessitatibus obcaecati suscipit, iste impedit iure voluptatum aliquid, incidunt repellat ad libero aliquam id quae eaque cupiditate neque. Incidunt dolores iure id? Repudiandae neque adipisci nam provident optio repellendus iure recusandae, vero exercitationem enim totam. Distinctio eligendi incidunt sequi a veniam saepe illum eos, corrupti eaque maxime blanditiis mollitia animi? Tenetur, neque? Nisi quas quisquam, obcaecati vero ut laboriosam ab eum aliquid accusamus quod praesentium et! Architecto quo atque beatae explicabo reprehenderit placeat deserunt dolorum repellendus modi quod dolores voluptas voluptatum vero sunt laudantium consequatur voluptate odit nemo, doloribus quia facere. Ad tempora quod fuga, sapiente asperiores delectus blanditiis quas nesciunt enim, incidunt sunt numquam facilis beatae provident repellendus voluptatum maiores quis magnam aut voluptatibus at quos quibusdam magni officia. Impedit delectus consequatur, at libero omnis obcaecati nisi neque ipsum quia. Voluptas itaque aspernatur quos illum sed. Officiis maxime totam itaque officia veritatis molestiae aspernatur consequatur dolores recusandae, nobis illum odio quae ea blanditiis odit corrupti vero ullam similique eveniet ipsam culpa reprehenderit. Ad modi placeat consequuntur ex doloremque harum facilis eum fugit.</div>
    <article id="" v-on:scroll="onScroll($event)">
        <h1>
            {{ title }}
        </h1>
        <p>
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perferendis inventore odit neque natus nostrum quaerat id optio iure iusto eum velit praesentium porro sunt, consequatur voluptas asperiores blanditiis repellendus ut.
        </p>
        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore laudantium temporibus a sequi veniam consequuntur doloribus, harum repudiandae. Animi recusandae neque excepturi autem maxime possimus nobis, exercitationem ratione magni aperiam?
        </p>
        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p id="scrollTrackPercent">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>        <br><br>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto explicabo eius quibusdam iure, eligendi, eos deserunt amet libero iste nesciunt at et a similique ullam aspernatur. Molestiae modi aut enim.
        </p>vv
    </article>
</template>
<script setup>

import CustomProgress from './CustomProgress.vue';
    import {ref} from 'vue'
    const props = defineProps(['title'])
    const percentage = ref(0)

</script>
<style lang="scss" scoped>
    article{
        width: 100%;
        max-width: 500px;
        height: 100%;
        max-height: 300px;
        margin: 0 auto;
        padding: 15px;
        background-color: #FFFFFF;
        overflow: scroll;
        color: black;
    }
  .parent {
    min-width: 300px;
    background-color: blue;
    position: fixed;
    z-index: 1;
  }
  .prc {
    width: v-bind(percentage+"%");
    transition: all .6s;
    background-color: green;
    position: 'absolute';
    z-index: 200;
  }
</style>