<template>
    <div>
        <button @click="plus">+</button>{{ modelValue }}<button @click="minus">-</button>
    </div>
</template>
<script>
    import { defineComponent } from 'vue';
    export default defineComponent({
        name:"NumberPicker",
        emits: [
            "update:modelValue"
        ],
        props: {
            modelValue: {
                type: Number,
                default: 0
            }
        },

        methods: {
            plus(){
                this.$emit('update:modelValue', this.modelValue+1)
            },
            minus(){
                if (this.modelValue !== 0) {
                    this.$emit('update:modelValue', this.modelValue-1)
                }
            }
        },
        // watch:{
        //     counter(value, oldValue){
        //         if (value > oldValue) {
        //             this.$emit("plus", value)
        //         }else{
        //             this.$emit("minus", value)
        //         }
        //         this.$emit("change", value)
        //     }
        // }
    })
</script>

<style lang="scss" scoped>

</style>