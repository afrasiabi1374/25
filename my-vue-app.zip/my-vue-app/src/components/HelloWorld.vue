<template>
    <div>
        <h1>
            {{ msg }}
        </h1>
        <div>{{ counter }}</div>
        <div>
            {{ computedCounter }}
        </div>
        <div>
            {{ fullName }}
        </div>
        <button @click="plus(3)">plus</button>
        <button @click="customButtonClicked">
            my custom button
        </button>

    </div>
</template>
<script lang="ts">

import { defineComponent } from 'vue';
export default defineComponent({
    emits: {
        clickCustomButton:(msg:string)=>{

        }
    },
    props: {
        msg: {
            type: String,
            default: "hello"
        },
        flag: {
            type: Boolean,
            required: true
        },
        variant: {
            type: String,
            validator: (value: string) => {
                return ['error', 'success', 'warning'].includes(value)
            }
        }
    },
    data(){
        return {
            counter: 0,
            firstName: "ali",
            lastName: "ziya"
        }
    },
    methods:{
        plus(step){
            this.counter = this.counter+step
        },
        customButtonClicked(){
            this.$emit('clickCustomButton', 85)
        }
    },
    computed:{
        computedCounter(){
            return this.counter+10
        },
        fullName(){
            return this.firstName  + ' ' + this.lastName
        }
    }
})
</script>./LifeCycles.vue