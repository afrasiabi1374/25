<template>
</template>
<script setup>
import LifeCycles from './components/LifeCycles.vue';


</script>
<style>

</style>