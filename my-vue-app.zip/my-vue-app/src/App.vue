<template>
  <div id="app">
    <!-- <HelloWorld  msg="hello world" :flag="false" @clickCustomButton="clickedButton" variant="success" />
     <!-- <post title="درصد خوانده شده" /> -->
      <!-- s --> 
      <number-picker
        v-model="counter"
        @modevalue:update="changeNumberPicker"
      ></number-picker>
  </div>
</template>
  <script setup>
  import { ref } from 'vue';
  import NumberPicker from './components/NumberPicker.vue';

    let counter = ref(0)

  </script>
<style  lang="scss">
  body {
    margin: 0;
    padding: 0;
    #app {
      padding: 25px;
    }
  }
</style>
