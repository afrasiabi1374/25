import autoBind from 'auto-bind';
import { getEnv,log,toNumber,toObjectId } from './utils.js';
import {encode} from 'html-entities';
import {URLSearchParams} from 'node:url';


export default class Helper
{
    constructor()
    {
        autoBind(this);
    }

    safeString(str){
        try {
            return encode(str);
        }
        catch(e) {
            return '';
        }
    }

    toNumber(str){
        return toNumber(str);
    }

    toObjectId(str,toString = false){
        return toObjectId(str,toString);
    }

    getPage(i){
        try{
            let page = this.toNumber(i);
            return (page <= 0) ? 1 : page;
        }
        catch(e){
            return 1;
        }
    }

    sort(i){
        try{
            let limit = this.toNumber(i);
            if(limit <= 0 || limit > 100)
                return getEnv('ROWS_PRE_PAGE','number');
            else
                return limit;
        }
        catch(e){
            return getEnv('ROWS_PRE_PAGE','number');
        }
    }



    getSortParams(sortFields, sort_field_input='', sort_type_input = 'asc'){
        try{
            let sort_field = '_id';
            if(sort_field_input != '' && sortFields.includes(sort_field_input))
                sort_field = sort_field_input
            const sort_type = (sort_type_input === 'asc') ? 1 : -1;
            return {
                sort_field,sort_type
            };
        }
        catch(e){
            return {
                "sort_field" : "_id",
                "sort_type" : -1
            };
        }
    }
    getLimit(i){
        try{
            let limit = this.toNumber(i);
            if(limit <= 0 || limit > 100)
                return getEnv('ROWS_PRE_PAGE','number');
            else
                return limit;
        }
        catch(e){
            return getEnv('ROWS_PRE_PAGE','number');
        }
    }
}