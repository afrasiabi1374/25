import {Schema} from 'mongoose';
export default new Schema({
    updateAt: {
        type: Date
    },
    createdAt: {
        type: Date
    },
    name : {
        type : String,
        required : true,
    },
    age : {
        type : Number
    },
    address: {
        type: String
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    admin: {
        type: Boolean,
        default: false
    }
});