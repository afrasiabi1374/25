import getArticles from "./query/getArticles.js";
import getArticle from "./query/getArticle.js";
import getComments from "./query/getComments.js";

export default {
    getArticles,
    getArticle,
    getComments
}