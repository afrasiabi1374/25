JS_LANG = {
    "test" : "man en en en"
};