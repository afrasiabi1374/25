$(window).on('load', function() {

    $('#parent_id').select2({"width":"100%"});


});



function deleteRow(title,id,url)
{
    Swal.fire({
        title: t('category.delete_title'),
        html: t('category.delete_text',{"title":title}),
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText:  t('logout_yes'),
        cancelButtonText: t('logout_no'),
      }).then((result) => {
        if (result.isConfirmed) 
        {
          url += '&del_id=' + id;
          redirect(url);
        }
    });
}